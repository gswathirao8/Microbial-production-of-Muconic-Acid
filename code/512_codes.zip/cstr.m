function dYdt = cstr(t, Y, F)
%function encapsulates cstr design equationd for muconic acid 
%production from glucose in C. Glutamicum bacteria

%INPUT - t, Y, kinetic parameters
%OUTPUT - set of odes packed inside dY/dt

    x = Y(1); % Biomass concentration
    s = Y(2); % Substrate concentration
    p = Y(3); % Product concentration

    % parameters
    % mu_max = 0.0056*60;
    % Ks = 0.5;
    % p_max = 50; %assumed, later optimize
    % Yxs = 0.185; %gDCW/g glucose, Lee_et_al 2018
    % Ypx = 0.892; %gMA/ gDCW, Lee_et_al 2018
    % F = 0.0056*7*60; %L/hr, calc from Lee et al 2018
    % V = 7; %L, Lee_et_al 2018
    % D = F/V;
    % sf = 40.029; %g/L, Lee_et_al 2018
    % m = 0.01; %assumed, later optimize

    % mu_max = 0.336;
    Ks = 0.5;
    p_max = 50; %assumed, later optimize
    Yxs = 0.18; %gDCW/g glucose, Lee_et_al 2018
    Ypx = 0.9; %gMA/ gDCW, Lee_et_al 2018
    %L/hr, calc from Lee et al 2018
    V = 7; %L, Lee_et_al 2018
    D = F/V;
    sin = 15.029; %g/L, Lee_et_al 2018
    m = 0.01; %assumed, later optimize

    % odes
    mu = mu_max * (1 - p / p_max) * (s / (Ks + s)); %product inhibition
    dxdt = mu*x - D*x - m*x ;
    dsdt = D*(sin - s) - (mu/Yxs)*x - m*x;
    dpdt = mu*Ypx*x  - D*p;

    % pack derivatives
    dYdt = [dxdt; dsdt; dpdt];
end
