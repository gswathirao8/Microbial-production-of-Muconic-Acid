clc; clear

% Initial conditions [X0, S0, P0]
Y0 = [0.1; 10; 0];

% Time span
tspan = [0 100];

% Solve ODE
[t, Y] = ode15s(@(t, Y) cstr(t, Y, 0.3345), tspan, Y0);

% Extract solutions
x = Y(:, 1);
s = Y(:, 2);
p = Y(:, 3);

% Plot results
figure;
plot(t, x, 'b', 'LineWidth', 2);
hold on;
plot(t, s, 'r', 'LineWidth', 2);
plot(t, p, 'g', 'LineWidth', 2);
legend('Biomass X', 'Substrate S', 'Product P');
xlabel('Time');
ylabel('Concentration');
title('CSTR Bioreactor Dynamics');
grid on;

%% Optimize flowrate
global F_trials P_trials
F0 = 0.01;

% Initialize storage variables
F_trials = [];
P_trials = {};

lb = 0;
ub = 0.336; %mu_max = D
options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'interior-point', 'OutputFcn', @outfun);

[Fopt, fval, exitflag, output] = fmincon(@(F) Fobj(F), F0, [], [], [], [], lb, ub, [], options);

%Plot variations
figure;
hold on;
for i = 1:length(F_trials)
    plot(linspace(0, 100, length(P_trials{i})), P_trials{i}, 'DisplayName', sprintf('D = %.4f hr^-1', F_trials(i)));
end
hold off;
xlabel('Time (hr)');
ylabel('Product Concentration P (g/L)');
title('Product Concentration Over Time for Different Dilution Rates');
legend show;
grid on;

%% HELPER FUNCTIONS
%optimize flowrate
function obj = Fobj(F)
    [t, Y] = ode15s(@(t, Y) cstr(t, Y, F), [0 100], [0.1; 15; 0]);
    Pf = Y(end, 3); % Final product conc
    obj = -Pf; % Negative for max
end

%outfun to store and plot
function stop = outfun(F, optimValues, state)
    stop = false;
    global F_trials P_trials
    if isequal(state,'iter')
        % Store current F and corresponding product concentration profile
        F_trials(end+1) = F;
        [~, Y] = ode15s(@(t, Y) cstr(t, Y, F), [0 100], [0.1; 15; 0]);
        P_trials{end+1} = Y(:, 3);
    end
end